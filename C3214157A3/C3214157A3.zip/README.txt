// SENG2250 System and Network Security
// School of Electrical Engineering and Computing
// Semester 2, 2018
// Assignment 3 Task 2
// Binbin Wang
// c3214157

use java jdk 1.8

compilation: javac C3214157.java
execution: java C3214157

